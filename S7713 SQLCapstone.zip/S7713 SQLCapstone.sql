use sqlproject;
select * from amazon;
select distinct * from amazon;
show columns from amazon;
select * from amazon where coalesce('Invoice ID','Branch','City','Customer type','Gender','Product line',
									'Unit price','Quantity','Tax 5%','Total','Date','Time','Payment','cogs',
                                    'gross margin percentage','gross income','Rating') is null;
                                      
-- Feature Engineering:
/*
Add a new column named timeofday to give insight of sales in the Morning, Afternoon and Evening. 
This will help answer the question on which part of the day most sales are made.
*/
alter table amazon
add column timeofday varchar(20);
update amazon
set timeofday=
case
   when time between '06:00:00' and '12:00:00' then 'morning'
   when time between '12:01:00' and '16:00:00' then 'afternoon'
   else 'evening'
end;
select * from amazon;
/*
 Add a new column named dayname that contains the extracted days of the week on which the given transaction took place 
 (Mon, Tue, Wed, Thur, Fri).
 This will help answer the question on which week of the day each branch is busiest.
 */
 
 alter table amazon add column dayname varchar(10);
 update amazon 
 set dayname=dayname(date);
 
 
 /*
  Add a new column named monthname that contains the extracted months of the year on which the given transaction took place (Jan, Feb, Mar). 
  Help determine which month of the year has the most sales and profit.
  */
   
   alter table amazon
   add column monthname varchar(20);
   update amazon
   set monthname=monthname(date);
 
--------- What is the count of distinct cities in the dataset? --------
select count(distinct city) as citys from amazon;

------ For each branch, what is the corresponding city?--------
select branch,city from amazon;

alter table amazon
RENAME COLUMN `Product line` TO product_line;
-------- What is the count of distinct product lines in the dataset?--------
SELECT COUNT(DISTINCT product_line) AS distinct_product_lines_count
FROM amazon;

------ Which payment method occurs most frequently? ------
SELECT payment, COUNT(*) AS frequency
FROM amazon
GROUP BY payment
ORDER BY frequency DESC;
select max(payment) from amazon;

------ Which product line has the highest sales? --------
SELECT product_line, sum(quantity) as  highestsales from amazon
group by product_line
order by highestsales desc;

----- How much revenue is generated each month------
select monthname,sum(total) as revenue from amazon
group by monthname
order by revenue desc;

----- In which month did the cost of goods sold reach its peak-----
select monthname,sum(cogs) as total_cogs from amazon
group by monthname 
order by total_cogs desc
limit 1; 
select * from amazon;

-------- Which product line generated the highest revenue----
select product_line,sum(total) as revenue_p from amazon
group by product_line
order by revenue_p desc;

------ In which city was the highest revenue recorded?-----
select city,sum(total) as  highest_revenue  from amazon
group by city
order by  highest_revenue  desc;

-------- Which product line incurred the highest Value Added Tax-----
SELECT product_line, SUM(`Tax 5%`) AS high_tax
FROM amazon
GROUP BY product_line
ORDER BY high_tax DESC;

------ For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."-----
select product_line,sum(quantity) as total,
case
 when sum(quantity)>(select avg(quantity) from amazon) then "good"
 else "bad"
end as sales_quality
from amazon
group by product_line;

-------- Identify the branch that exceeded the average number of products sold----- 
select branch,sum(quantity) as total_products_sold,
(select avg(quantity)from amazon) as avarage_products_sold 
from amazon
group by branch
having sum(quantity) > (select avg(quantity)from amazon);
 
 -------- Which product line is most frequently associated with each gender?------
 select product_line,gender,count(*) as fregender from amazon
 group by product_line,gender
 order by  gender,fregender desc;
 select* from amazon
 
 -------- Calculate the average rating for each product line.------
 select product_line,avg(rating)as avg_rating from amazon
 group by product_line
 order by avg_rating desc; 
 
 -------- Count the sales occurrences for each time of day on every weekday-----
 select timeofday,dayname,count(*)  as sales_occurrences from amazon
 group by timeofday,dayname
 order by sales_occurrences desc;
 
 -------- Identify the customer type contributing the highest revenue.------
alter table amazon
RENAME COLUMN  `Customer type` TO Customer_type;
 select Customer_type ,sum(total) as highest_revenue from amazon
 group by  Customer_type
 order by  highest_revenue desc ;
 
 ----- Determine the city with the highest VAT percentage.----
SELECT 
    city,
    SUM(`Tax 5%`) / SUM(total) AS vat_percentage
FROM 
    amazon
GROUP BY 
    city
ORDER BY 
    vat_percentage DESC
LIMIT 1;

-------- Identify the customer type with the highest VAT payments.-----
SELECT customer_type, SUM(`Tax 5%`) AS cus_high_tax
FROM amazon
GROUP BY customer_type
ORDER BY cus_high_tax DESC; 
 
 -------- What is the count of distinct customer types in the dataset?-----
 select count(distinct customer_type)as cus_dis from amazon;
 
 -------- What is the count of distinct payment methods in the dataset?------
 select count(distinct payment)as distinct_payment_methods from amazon;
 
 -------- Which customer type occurs most frequently?-------
 -------- Identify the customer type with the highest purchase frequency.------
 select customer_type,count(*) as m_freq from amazon
 group by customer_type
 order by m_freq desc ; 
 
 -------- Determine the predominant gender among customers.------
 select gender,count(*) as count  from amazon
 group by gender
 order by count desc;
 
 -------- Examine the distribution of genders within each branch.
SELECT gender,branch, COUNT(*) AS frequency
FROM amazon
GROUP BY gender,branch
ORDER BY  branch,frequency DESC;

-------- Identify the time of day when customers provide the most ratings.
select timeofday,count(rating)as rating_count from amazon
group by timeofday
order by rating_count ;

-------- Determine the time of day with the highest customer ratings for each branch.
select timeofday,branch,count(rating) as b_rating_count from amazon
group by timeofday,branch
order by  branch,b_rating_count desc;

-------- Identify the day of the week with the highest average ratings.
select dayname,avg(rating) as avg_rat from amazon
group by dayname
order by avg_rat desc;

-------- Determine the day of the week with the highest average ratings for each branch.
select dayname,branch,avg(rating) as b_avg_rat from amazon
group by dayname,branch
order by dayname,branch, b_avg_rat desc;